package com.mangareader.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LibraryUiState(
    val hasRoot: Boolean = false,
    val rootName: String? = null,
    val mangas: List<Manga> = emptyList(),
    val loading: Boolean = false,
    /** 一次性提示（Snackbar），显示后由界面调用 consumeMessage 清掉 */
    val message: String? = null
)

class LibraryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = LibraryRepository(app)

    private val _state = MutableStateFlow(LibraryUiState())
    val state: StateFlow<LibraryUiState> = _state.asStateFlow()

    init {
        if (repo.rootUri != null) {
            _state.update {
                it.copy(hasRoot = true, rootName = repo.rootDisplayName(), loading = true)
            }
            refresh()
        }
    }

    /** 用户选定了新的漫画根文件夹 */
    fun setRoot(uri: Uri) {
        repo.setRoot(uri)
        _state.update {
            it.copy(hasRoot = true, rootName = repo.rootDisplayName(), mangas = emptyList())
        }
        refresh()
    }

    /** 重新扫描根目录 */
    fun refresh() {
        if (repo.rootUri == null) {
            _state.update {
                it.copy(hasRoot = false, rootName = null, mangas = emptyList(), loading = false)
            }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val count = reload()
            _state.update {
                it.copy(message = if (count == 0) "没有找到含图片的文件夹" else null)
            }
        }
    }

    /** 把选中的图片复制进指定漫画文件夹 */
    fun addImages(manga: Manga, uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val added = runCatching { repo.addImages(manga.segments, uris) }.getOrDefault(0)
            reload()
            _state.update {
                it.copy(
                    message = if (added > 0) "已添加 $added 张图片"
                    else "添加失败：该文件夹没有写入权限或图片不可读"
                )
            }
        }
    }

    /** 用一张图设为该漫画的封面 */
    fun setCover(manga: Manga, uri: Uri) {
        viewModelScope.launch {
            val ok = runCatching { repo.setCustomCover(manga.id, uri) }.getOrDefault(false)
            reload()
            _state.update { it.copy(message = if (ok) "封面已更新" else "封面设置失败") }
        }
    }

    /** 恢复默认封面（该文件夹排序后的第一张图） */
    fun resetCover(manga: Manga) {
        viewModelScope.launch {
            runCatching { repo.resetCustomCover(manga.id) }
            reload()
            _state.update { it.copy(message = "已恢复默认封面") }
        }
    }

    /** 阅读页数据源 */
    suspend fun loadPages(manga: Manga): List<Uri> =
        runCatching { repo.pages(manga.segments) }.getOrDefault(emptyList())

    fun consumeMessage() {
        _state.update { it.copy(message = null) }
    }

    /** 重新扫描并更新列表，返回找到的漫画数量 */
    private suspend fun reload(): Int {
        val found = runCatching { repo.scan() }.getOrDefault(emptyList())
        _state.update {
            it.copy(
                loading = false,
                hasRoot = true,
                rootName = repo.rootDisplayName(),
                mangas = found
            )
        }
        return found.size
    }
}
