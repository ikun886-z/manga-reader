package com.mangareader.app

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/**
 * 阅读页：竖屏、竖直连续滚动。
 * 图片按屏幕宽度铺满、高度自适应（不裁切），所以长条漫画可以一滑到底。
 * 点一下图片可切换顶栏显示。
 */
@Composable
fun ReaderScreen(
    manga: Manga,
    loadPages: suspend () -> List<Uri>,
    onBack: () -> Unit
) {
    // null = 还在加载
    val pagesState by produceState<List<Uri>?>(initialValue = null, manga.id) {
        value = loadPages()
    }

    val listState = rememberLazyListState()
    var chromeVisible by remember { mutableStateOf(true) }

    val currentPage by remember {
        derivedStateOf { listState.firstVisibleItemIndex + 1 }
    }

    BackHandler { onBack() }

    // 阅读时保持屏幕常亮
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    val pages = pagesState

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        when {
            pages == null -> CircularProgressIndicator(
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )

            pages.isEmpty() -> Text(
                text = "这个文件夹里没有图片",
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )

            else -> LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize()
            ) {
                items(count = pages.size) { index ->
                    AsyncImage(
                        model = pages[index],
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF111111))
                            .clickable { chromeVisible = !chromeVisible }
                    )
                }
            }
        }

        if (chromeVisible) {
            Surface(
                color = Color.Black.copy(alpha = 0.72f),
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "返回",
                            tint = Color.White
                        )
                    }
                    Text(
                        text = manga.title,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp)
                    )
                    Text(
                        text = if (pages == null) "" else "$currentPage / ${pages.size}",
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                }
            }
        }
    }
}
