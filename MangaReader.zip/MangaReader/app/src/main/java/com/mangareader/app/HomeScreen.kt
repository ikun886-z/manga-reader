package com.mangareader.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/**
 * 封面网格首页：每个含图片的文件夹显示为一张封面卡片，
 * 封面默认取该文件夹排序后的第一张图。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    state: LibraryUiState,
    snackbarHostState: SnackbarHostState,
    onOpen: (Manga) -> Unit,
    onRefresh: () -> Unit,
    onPickRoot: () -> Unit,
    onAddImages: (Manga) -> Unit,
    onSetCover: (Manga) -> Unit,
    onResetCover: (Manga) -> Unit
) {
    // 长按封面后弹出的操作对象
    var actionTarget by remember { mutableStateOf<Manga?>(null) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("漫画库", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = when {
                                !state.hasRoot -> "还没有选择文件夹"
                                state.loading -> "正在扫描…"
                                else -> "${state.rootName ?: ""} · ${state.mangas.size} 本"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    TextButton(onClick = onRefresh, enabled = state.hasRoot) { Text("刷新") }
                    TextButton(onClick = onPickRoot) { Text("换目录") }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            when {
                !state.hasRoot -> EmptyState(
                    title = "还没有漫画文件夹",
                    description = "选择一个装有漫画的文件夹（例如 内部存储/Comics）。\n每个内部有图片的文件夹会被识别为一本漫画。",
                    buttonText = "选择漫画文件夹",
                    onClick = onPickRoot
                )

                state.loading && state.mangas.isEmpty() -> CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )

                state.mangas.isEmpty() -> EmptyState(
                    title = "没有找到漫画",
                    description = "所选文件夹里没有找到含图片的子文件夹。\n换一个目录，或往里面放入图片后再刷新。",
                    buttonText = "换目录",
                    onClick = onPickRoot
                )

                else -> LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.mangas, key = { it.id }) { manga ->
                        MangaCard(
                            manga = manga,
                            onClick = { onOpen(manga) },
                            onLongClick = { actionTarget = manga }
                        )
                    }
                }
            }
        }
    }

    val target = actionTarget
    if (target != null) {
        AlertDialog(
            onDismissRequest = { actionTarget = null },
            title = { Text(target.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    Text(
                        text = "共 ${target.pageCount} 页",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(
                        onClick = {
                            actionTarget = null
                            onAddImages(target)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("添加图片到这本漫画") }

                    TextButton(
                        onClick = {
                            actionTarget = null
                            onSetCover(target)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("用一张图设为封面") }

                    if (target.customCover) {
                        TextButton(
                            onClick = {
                                actionTarget = null
                                onResetCover(target)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("恢复默认封面（第一张图）") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { actionTarget = null }) { Text("关闭") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MangaCard(
    manga: Manga,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.7f) // 竖版封面：宽 = 高 × 0.7
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            AsyncImage(
                model = manga.coverUri,
                contentDescription = manga.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (manga.customCover) {
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                ) {
                    Text(
                        text = "自定义",
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Text(
            text = manga.title,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp)
        )
        Text(
            text = "${manga.pageCount} 页",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 2.dp)
        )
    }
}

@Composable
private fun EmptyState(
    title: String,
    description: String,
    buttonText: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = title, style = MaterialTheme.typography.titleMedium)
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 10.dp, bottom = 22.dp)
        )
        Button(onClick = onClick) { Text(buttonText) }
    }
}
