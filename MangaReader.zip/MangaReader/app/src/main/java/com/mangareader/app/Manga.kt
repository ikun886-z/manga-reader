package com.mangareader.app

import android.net.Uri

/**
 * 一本漫画 = 一个「内部有图片的文件夹」。
 *
 * [segments] 是从根目录开始的相对路径片段，例如 ["海贼王", "第01卷"]；
 * 根目录本身含图片时用空列表表示。
 *
 * 为什么存相对路径而不是直接存子文件夹的 URI：
 * SAF 返回的子项 URI 是「document URI」，单独使用时无法再列目录、无法再往下钻
 * （DocumentFile.fromSingleUri 的 listFiles() 会抛异常）。
 * 只有始终从 tree 根目录逐级 findFile 拿到的 DocumentFile 才支持 listFiles()。
 */
data class Manga(
    val segments: List<String>,
    val title: String,
    val coverUri: Uri?,
    val pageCount: Int,
    val customCover: Boolean = false
) {
    /** 稳定唯一标识，用于 key 和封面记录的键 */
    val id: String get() = segments.joinToString("/")
}
