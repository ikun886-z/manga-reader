package com.mangareader.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 漫画库仓库：负责 SAF 根目录的保存、递归扫描、读取页列表、追加图片、自定义封面。
 * 所有耗时操作都在 IO 线程执行。
 */
class LibraryRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** 用户选定的漫画根目录（持久化保存，重启后仍有效） */
    var rootUri: Uri?
        get() = prefs.getString(KEY_ROOT, null)?.let(Uri::parse)
        private set(value) {
            prefs.edit().putString(KEY_ROOT, value?.toString()).apply()
        }

    // ---------------------------------------------------------------- 根目录

    /**
     * 记住用户选中的文件夹，并申请长期读写权限。
     * 必须先申请到读权限，扫描才能跨重启生效。
     */
    fun setRoot(uri: Uri) {
        val resolver = context.contentResolver
        try {
            resolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // 某些提供方只给只读权限，退化为只读（此时「添加图片」会失败）
            try {
                resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
                // 拿不到持久权限也不崩溃，本次会话内仍可用
            }
        }
        rootUri = uri
    }

    fun clearRoot() {
        rootUri = null
    }

    /** 根文件夹显示名，用于首页副标题 */
    fun rootDisplayName(): String? = runCatching { rootDocument()?.name }.getOrNull()

    private fun rootDocument(): DocumentFile? =
        rootUri?.let { runCatching { DocumentFile.fromTreeUri(context, it) }.getOrNull() }

    /**
     * 从根目录逐级下钻定位文件夹。永远从 tree 根开始，拿到的才是可列目录的 DocumentFile。
     */
    private fun resolve(segments: List<String>): DocumentFile? {
        var current = rootDocument() ?: return null
        for (segment in segments) {
            current = runCatching { current.findFile(segment) }.getOrNull() ?: return null
        }
        return current
    }

    // ---------------------------------------------------------------- 扫描

    /** 递归扫描根目录，返回所有漫画（按标题排序） */
    suspend fun scan(): List<Manga> = withContext(Dispatchers.IO) {
        val root = rootDocument() ?: return@withContext emptyList()
        val found = ArrayList<Manga>()
        collect(root, emptyList(), found)
        found.sortedBy { it.title.lowercase() }
    }

    private fun collect(dir: DocumentFile, segments: List<String>, out: MutableList<Manga>) {
        val children = listChildren(dir)
        val images = ArrayList<DocumentFile>()
        val dirs = ArrayList<DocumentFile>()
        for (child in children) {
            if (child.isDirectory) dirs += child else if (isImage(child.name)) images += child
        }

        // 当前文件夹内部有图片 → 它就是一本漫画
        if (images.isNotEmpty()) {
            val sorted = images.sortedWith(compareBy(NaturalOrder) { it.name.orEmpty() })
            val id = segments.joinToString("/")
            val customCover = customCoverUri(id)
            out += Manga(
                segments = segments,
                title = dir.name ?: "未命名",
                coverUri = customCover ?: sorted.first().uri,
                pageCount = sorted.size,
                customCover = customCover != null
            )
        }

        // 继续往下钻，子文件夹各自成为一本漫画
        for (child in dirs) {
            val name = child.name ?: continue
            collect(child, segments + name, out)
        }
    }

    // ---------------------------------------------------------------- 阅读

    /** 读取某本漫画的全部图片，按文件名自然排序 */
    suspend fun pages(segments: List<String>): List<Uri> = withContext(Dispatchers.IO) {
        val dir = resolve(segments) ?: return@withContext emptyList()
        listChildren(dir)
            .filter { !it.isDirectory && isImage(it.name) }
            .sortedWith(compareBy(NaturalOrder) { it.name.orEmpty() })
            .map { it.uri }
    }

    // ---------------------------------------------------------------- 追加图片

    /**
     * 把用户选中的图片复制进目标漫画文件夹，返回成功数量。
     * 需要该目录的写权限（选目录时已一并申请）。
     */
    suspend fun addImages(segments: List<String>, sources: List<Uri>): Int =
        withContext(Dispatchers.IO) {
            val dir = resolve(segments) ?: return@withContext 0
            val resolver = context.contentResolver
            var added = 0

            for (source in sources) {
                val name = displayName(source) ?: "image_${System.currentTimeMillis()}.jpg"
                val mime = resolver.getType(source) ?: mimeFor(name)

                val target = try {
                    DocumentsContract.createDocument(resolver, dir.uri, mime, name)
                } catch (_: Exception) {
                    null
                } ?: continue

                try {
                    resolver.openOutputStream(target)?.use { output ->
                        resolver.openInputStream(source)?.use { input -> input.copyTo(output) }
                    }
                    added++
                } catch (_: Exception) {
                    // 复制失败就删掉半成品，避免留下 0 字节文件
                    runCatching { DocumentsContract.deleteDocument(resolver, target) }
                }
            }
            added
        }

    // ---------------------------------------------------------------- 自定义封面

    /**
     * 自定义封面存进 App 私有目录，不写进漫画文件夹 ——
     * 这样封面图不会混进正文页，也不用担心覆盖原文件。
     */
    fun customCoverUri(mangaId: String): Uri? {
        val path = prefs.getString(KEY_COVER + mangaId, null) ?: return null
        val file = File(path)
        return if (file.exists() && file.length() > 0) Uri.fromFile(file) else null
    }

    suspend fun setCustomCover(mangaId: String, source: Uri): Boolean = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, "covers").apply { mkdirs() }
        val safeName = if (mangaId.isEmpty()) "root" else mangaId.replace('/', '_')
        val file = File(dir, "$safeName.img")

        try {
            context.contentResolver.openInputStream(source)?.use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            } ?: return@withContext false
        } catch (_: Exception) {
            return@withContext false
        }

        if (file.length() == 0L) return@withContext false
        prefs.edit().putString(KEY_COVER + mangaId, file.absolutePath).apply()
        true
    }

    suspend fun resetCustomCover(mangaId: String) = withContext(Dispatchers.IO) {
        prefs.edit().remove(KEY_COVER + mangaId).apply()
    }

    // ---------------------------------------------------------------- 工具

    private fun listChildren(dir: DocumentFile): Array<DocumentFile> =
        try {
            dir.listFiles()
        } catch (_: Exception) {
            emptyArray()
        }

    private fun displayName(uri: Uri): String? = try {
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    } catch (_: Exception) {
        null
    }

    private fun mimeFor(name: String): String =
        when (name.substringAfterLast('.', "").lowercase()) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "bmp" -> "image/bmp"
            "heic", "heif" -> "image/heic"
            else -> "image/jpeg"
        }

    companion object {
        private const val PREFS = "manga_reader"
        private const val KEY_ROOT = "root_uri"
        private const val KEY_COVER = "cover_"

        private val IMAGE_EXT = setOf(
            "jpg", "jpeg", "jpe", "jfif", "png", "webp",
            "gif", "bmp", "avif", "heic", "heif", "tif", "tiff"
        )

        fun isImage(name: String?): Boolean {
            if (name.isNullOrEmpty()) return false
            return name.substringAfterLast('.', "").lowercase() in IMAGE_EXT
        }
    }
}

/**
 * 自然排序：让 1.jpg / 2.jpg / 10.jpg 按人的直觉排列，
 * 而不是字符串排序出来的 1 / 10 / 2。
 */
object NaturalOrder : Comparator<String> {
    override fun compare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var x = i
                while (x < a.length && a[x].isDigit()) x++
                var y = j
                while (y < b.length && b[y].isDigit()) y++

                val na = a.substring(i, x).trimStart('0')
                val nb = b.substring(j, y).trimStart('0')
                val cmp = if (na.length != nb.length) na.length - nb.length else na.compareTo(nb)
                if (cmp != 0) return cmp

                i = x
                j = y
            } else {
                val cmp = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                if (cmp != 0) return cmp
                i++
                j++
            }
        }
        return (a.length - i) - (b.length - j)
    }
}
