package com.mangareader.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MangaReaderTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
private fun AppRoot(vm: LibraryViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // 当前打开的漫画，null 表示停留在首页网格
    var openedManga by remember { mutableStateOf<Manga?>(null) }

    // 系统选择器返回时用它们找回「操作对象」
    var pendingAddTarget by remember { mutableStateOf<Manga?>(null) }
    var pendingCoverTarget by remember { mutableStateOf<Manga?>(null) }

    // 选择漫画根文件夹（SAF，授予持久读写权限）
    val folderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) vm.setRoot(uri)
    }

    // 多选图片，追加到某本漫画
    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val target = pendingAddTarget
        pendingAddTarget = null
        if (target != null && uris.isNotEmpty()) vm.addImages(target, uris)
    }

    // 单选一张图作为封面
    val coverPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        val target = pendingCoverTarget
        pendingCoverTarget = null
        if (target != null && uri != null) vm.setCover(target, uri)
    }

    LaunchedEffect(state.message) {
        val message = state.message
        if (message != null) {
            snackbarHostState.showSnackbar(message)
            vm.consumeMessage()
        }
    }

    val opened = openedManga
    if (opened != null) {
        ReaderScreen(
            manga = opened,
            loadPages = { vm.loadPages(opened) },
            onBack = { openedManga = null }
        )
    } else {
        HomeScreen(
            state = state,
            snackbarHostState = snackbarHostState,
            onOpen = { openedManga = it },
            onRefresh = { vm.refresh() },
            onPickRoot = { folderPicker.launch(null) },
            onAddImages = { manga ->
                pendingAddTarget = manga
                imagePicker.launch(arrayOf("image/*"))
            },
            onSetCover = { manga ->
                pendingCoverTarget = manga
                coverPicker.launch("image/*")
            },
            onResetCover = { vm.resetCover(it) }
        )
    }
}
