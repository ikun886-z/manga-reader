# 本工程未启用代码混淆（isMinifyEnabled = false），此文件留空即可。
# 若日后开启混淆，Coil / Compose 通常无需额外规则。
